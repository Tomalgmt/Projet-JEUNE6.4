<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <meta charset="utf-8" http-equiv="content-type" content="text/html;charset=iso-8859-1"/>
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <div class="banniere">
        <a href= "main.php">
        <img src="LOGOS_JEUNES_1.png" class="partenairelogo" width="300px" style="margin-left: 2%;">
        <div class="bannieretextepartenaire">
            <a>PARTENAIRES  </a>
        </div>
    </div>
    <nav class="liens">
        <a href="page_authentification.php" class="Jeunebutton">JEUNE</a>
        <a href="Référent.php" class="Référentbutton">REFERENT</a>
        <a href="Consultant.php" class="Consultantbutton">CONSULTANT</a>
        <div>
            <a class="Partenairebuttonpage">PARTENAIRE</a>
        </div>
    </nav>
    <br>
    </div>
    <br>
    <div class="Partenairetexte1">
        <a>JEUNES6.4 est un dispositif issu de la <a style="color: rgb(0, 0, 138);">charte de l’engagement</a> pour la<br>jeunesse signée en 2013 par des partenaires institutionnels...</a>
    </div>
    <br>
    <div>
        <img src="Partenaireslogo.png" class="partenairepartenaire">
    </div>
    <div style="margin-left: 30%; margin-top: 1%;">
        <a  class="partenairebottomtext">...qui ont décidé de mettre en commun leurs actions pour les jeunes
        <br>des Pyrénées-Atlantiques.</a>
    </div>
</body>

</html>