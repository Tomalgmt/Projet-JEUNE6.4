function afficherFormulaireInscription() {
    let formulaire_inscription = document.getElementById("formulaire_inscription");
    let formulaire_connexion = document.getElementById("Formulaire_Connexion");

        
        formulaire_connexion.style.display = "none";
        formulaire_inscription.style.display = "block";
    }