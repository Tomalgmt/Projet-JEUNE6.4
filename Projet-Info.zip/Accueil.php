<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
    <meta charset="utf-8" http-equiv="content-type" content="text/html;charset=iso-8859-1"/>
    <link rel="stylesheet" href="style.css">

</head>

<body>

<div class="entreebody">
    
    <br><div class="diventreetitre"><h1 class="entreetitre">Pour faire de l ’engagement une valeur !</h1></div>
    <img src="LOGOS_JEUNES_1.png" class="entreelogo" width="550px">
    
    <br><br>

    <div class="diventreetxt"><a>... l’expression d’un potentiel,<br>la promesse d’une richesse !</a></div>
    <br><br><br><br>
    <a href="main.php" class="entreebouton">ENTRER</a>
    <br><br><br><br><br>
</div>

<p class="entreetextebas"><br>JEUNES 6.4 est un dispositif de valorisation de l’engagement des jeunes en Pyrénées-
    <br>Atlantiques soutenu par l’Etat, le Conseil général, le conseil régional, les CAF Béarn-Soule et 
    <br> Pays Basque, la MSA, l’université de Pau et des pays de l’Adour, la CPAM.
</p>
    

</body>

</html>